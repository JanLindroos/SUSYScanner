* TLpsvars.h
* this file is part of FeynHiggs
* generated 15 Jul 2009 11:57 by TLps.m

#define MUEc vc(1,vs)
#define MUEr vr(1,vs)
#define Xtc vc(2,vs)
#define Atc vc(3,vs)
#define Atr vr(5,vs)
#define Xbc vc(4,vs)
#define Abc vc(5,vs)
#define Abr vr(9,vs)
#define BSS2(s) vr(10+s,vs)
#define MBy vr(13,vs)
#define Deltab vr(14,vs)
#define MUEr2 vr(15,vs)
#define pMGl vr(16,vs)
#define pMGl2 vr(17,vs)
