* TLhrvars.h
* this file is part of FeynHiggs
* generated 30 Nov 2011 16:06


	ComplexType selfA0A0, selfh0A0, selfh0h0, selfh0HH, selfHHA0
	ComplexType selfHHHH, selfHmHp, tadA0, tadh0, tadHH, Cd(14356)
	ComplexType Ce(1902), Co(2526), Cr(139), dAf133eps(-1:1)
	ComplexType dMf133eps(-1:1), dMSfsq1133eps(-1:1)
	ComplexType dMSfsq1143eps(-1:1), dMSfsq1233eps(-1:1)
	ComplexType dY33eps(-1:1), Opt(47)
	common /hrvar/ selfA0A0, selfh0A0, selfh0h0, selfh0HH
	common /hrvar/ selfHHA0, selfHHHH, selfHmHp, tadA0, tadh0
	common /hrvar/ tadHH, Cd, Ce, Co, Cr, dAf133eps, dMf133eps
	common /hrvar/ dMSfsq1133eps, dMSfsq1143eps, dMSfsq1233eps
	common /hrvar/ dY33eps, Opt
