{(adb*B0q[0, MCha2[Cha3], MSf2[1, 1, g1], Qew]*Delta[g1, g2]*MCha[Cha3]*
    Mf[2, g1]*SumOver[Cha3, 2]*UChaC[Cha3, 2]*VChaC[Cha3, 1])/
   (4*Sqrt[2]*CB*MW*Pi*SW2) + 
  (AlfaGF*B0q[0, MNeu2[Neu3], MSf2[Sfe3, 2, g1], Qew]*Delta[g1, g2]*
    MNeu[Neu3]*SumOver[Neu3, 4]*SumOver[Sfe3, 2]*
    (CB*MW*USf[Sfe3, 1, 2, g1]*(SW*ZNeuC[Neu3, 1] + CW*ZNeuC[Neu3, 2]) - 
     CW*Mf[2, g1]*USf[Sfe3, 2, 2, g1]*ZNeuC[Neu3, 3])*
    (2*CB*MW*SW*USfC[Sfe3, 2, 2, g1]*ZNeuC[Neu3, 1] + 
     CW*Mf[2, g1]*USfC[Sfe3, 1, 2, g1]*ZNeuC[Neu3, 3]))/
   (8*CB2*CW2*MW2*Pi*SW2), 
 ((adb*B1q[0, MCha2[Cha3], MSf2[1, 1, g1], Qew]*Delta[g1, g2]*
     SumOver[Cha3, 2]*VCha[Cha3, 1]*VChaC[Cha3, 1])/(4*Pi*SW2) + 
   (AlfaGF*B1q[0, MNeu2[Neu3], MSf2[Sfe3, 2, g1], Qew]*Delta[g1, g2]*
     SumOver[Neu3, 4]*SumOver[Sfe3, 2]*(CB*MW*USfC[Sfe3, 1, 2, g1]*
       (SW*ZNeu[Neu3, 1] + CW*ZNeu[Neu3, 2]) - CW*Mf[2, g1]*
       USfC[Sfe3, 2, 2, g1]*ZNeu[Neu3, 3])*
     (CB*MW*USf[Sfe3, 1, 2, g1]*(SW*ZNeuC[Neu3, 1] + CW*ZNeuC[Neu3, 2]) - 
      CW*Mf[2, g1]*USf[Sfe3, 2, 2, g1]*ZNeuC[Neu3, 3]))/
    (8*CB2*CW2*MW2*Pi*SW2))/2, 
 ((adb*B1q[0, MCha2[Cha3], MSf2[1, 1, g1], Qew]*Delta[g1, g2]*Mf2[2, g1]*
     SumOver[Cha3, 2]*UCha[Cha3, 2]*UChaC[Cha3, 2])/(8*CB2*MW2*Pi*SW2) + 
   (AlfaGF*B1q[0, MNeu2[Neu3], MSf2[Sfe3, 2, g1], Qew]*Delta[g1, g2]*
     SumOver[Neu3, 4]*SumOver[Sfe3, 2]*(2*CB*MW*SW*USf[Sfe3, 2, 2, g1]*
       ZNeu[Neu3, 1] + CW*Mf[2, g1]*USf[Sfe3, 1, 2, g1]*ZNeu[Neu3, 3])*
     (2*CB*MW*SW*USfC[Sfe3, 2, 2, g1]*ZNeuC[Neu3, 1] + 
      CW*Mf[2, g1]*USfC[Sfe3, 1, 2, g1]*ZNeuC[Neu3, 3]))/
    (8*CB2*CW2*MW2*Pi*SW2))/2}
