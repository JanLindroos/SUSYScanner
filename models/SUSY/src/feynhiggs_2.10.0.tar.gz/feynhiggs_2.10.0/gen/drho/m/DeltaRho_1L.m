{-(GF*B00[0, MSf2[1, 1, Gen3], MSf2[1, 1, Gen3]]*SumOver[Gen3, 3])/
  (2*Sqrt[2]*Pi^2), SumOver[All3, 6]*SumOver[Ind1, 3]*
  ((Sqrt[2]*GF*SW2*A0[MASf2[All3, 3]]*((-3 + 2*SW2)*UASf[All3, Ind1, 3]*
       UASfC[All3, Ind1, 3] + 2*SW2*UASf[All3, 3 + Ind1, 3]*
       UASfC[All3, 3 + Ind1, 3]))/(3*Pi^2) + 
   (GF*SW2*A0[MASf2[All3, bBR]]*((-3 + SW2)*UASf[All3, Ind1, bBR]*
       UASfC[All3, Ind1, bBR] + SW2*UASf[All3, 3 + Ind1, bBR]*
       UASfC[All3, 3 + Ind1, bBR]))/(3*Sqrt[2]*Pi^2)), 
 (GF*SumOver[All3, 6]*SumOver[All4, 6]*SumOver[Ind1, 3]*SumOver[Ind2, 3]*
   (3*B00[0, MASf2[All3, 3], MASf2[All4, bBR]]*UASf[All3, Ind1, 3]*
     UASf[All4, Ind2, bBR]*UASfC[All3, Ind2, 3]*UASfC[All4, Ind1, bBR] + 
    (-(B00[0, MASf2[All3, 3], MASf2[All4, 3]]*
        ((-3 + 4*SW2)*UASf[All4, Ind2, 3]*UASfC[All3, Ind2, 3] + 
         4*SW2*UASf[All4, 3 + Ind2, 3]*UASfC[All3, 3 + Ind2, 3])*
        ((-3 + 4*SW2)*UASf[All3, Ind1, 3]*UASfC[All4, Ind1, 3] + 
         4*SW2*UASf[All3, 3 + Ind1, 3]*UASfC[All4, 3 + Ind1, 3])) - 
      B00[0, MASf2[All3, bBR], MASf2[All4, bBR]]*
       ((-3 + 2*SW2)*UASf[All4, Ind2, bBR]*UASfC[All3, Ind2, bBR] + 
        2*SW2*UASf[All4, 3 + Ind2, bBR]*UASfC[All3, 3 + Ind2, bBR])*
       ((-3 + 2*SW2)*UASf[All3, Ind1, bBR]*UASfC[All4, Ind1, bBR] + 
        2*SW2*UASf[All3, 3 + Ind1, bBR]*UASfC[All4, 3 + Ind1, bBR]))/6))/
  (Sqrt[2]*Pi^2), SumOver[Gen3, 3]*SumOver[Sfe3, 2]*
  ((GF*B00[0, MSf2[1, 1, Gen3], MSf2[Sfe3, 2, Gen3]]*USf[Sfe3, 1, 2, Gen3]*
     USfC[Sfe3, 1, 2, Gen3])/(Sqrt[2]*Pi^2) + 
   (GF*SW2*A0[MSf2[Sfe3, 2, Gen3]]*
     (-(CW2*USf[Sfe3, 1, 2, Gen3]*USfC[Sfe3, 1, 2, Gen3]) + 
      SW2*USf[Sfe3, 2, 2, Gen3]*USfC[Sfe3, 2, 2, Gen3]))/(Sqrt[2]*Pi^2)), 
 -(GF*B00[0, MSf2[Sfe3, 2, Gen3], MSf2[Sfe4, 2, Gen3]]*SumOver[Gen3, 3]*
    SumOver[Sfe3, 2]*SumOver[Sfe4, 2]*((-1 + 2*SW2)*USf[Sfe4, 1, 2, Gen3]*
      USfC[Sfe3, 1, 2, Gen3] + 2*SW2*USf[Sfe4, 2, 2, Gen3]*
      USfC[Sfe3, 2, 2, Gen3])*((-1 + 2*SW2)*USf[Sfe3, 1, 2, Gen3]*
      USfC[Sfe4, 1, 2, Gen3] + 2*SW2*USf[Sfe3, 2, 2, Gen3]*
      USfC[Sfe4, 2, 2, Gen3]))/(2*Sqrt[2]*Pi^2)}
