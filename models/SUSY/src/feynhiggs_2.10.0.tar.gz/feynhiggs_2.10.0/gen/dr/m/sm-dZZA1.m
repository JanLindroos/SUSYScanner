(2*((-((Alfa*CW)/(Pi*SW)) + (Alfa*(-CW2 + SW2))/(4*CW*Pi*SW))*A0[MW2] + 
   (Alfa*MW2*(CW/SW + SW/CW)*B0i[bb0, 0, MW2, MW2])/(2*Pi) + 
   ((2*Alfa*CW)/(Pi*SW) - (Alfa*(-CW2 + SW2))/(2*CW*Pi*SW))*
    B0i[bb00, 0, MW2, MW2]))/MZ2
