Alfa/(8*Pi*SW2) + (Alfa*(-4 + SW2^(-1) + 4*SW2))/(16*CW2*Pi) + 
 (Alfa*B0i[bb1, 0, 0, MW2])/(4*Pi*SW2) + 
 (Alfa*(-4/CW2 + 1/(CW2*SW2) + (4*SW2)/CW2)*B0i[bb1, 0, 0, MZ2])/(8*Pi) + 
 (Alfa*B0i[bb1, 0, MCha2[Cha3], MSf2[1, 1, 2]]*SumOver[Cha3, 2]*VCha[Cha3, 1]*
   VChaC[Cha3, 1])/(4*Pi*SW2) + 
 (Alfa*B0i[bb1, 0, MNeu2[Neu3], MSf2[Sfe3, 2, 2]]*SumOver[Neu3, 4]*
   SumOver[Sfe3, 2]*USf[Sfe3, 1, 2, 2]*USfC[Sfe3, 1, 2, 2]*
   (SW*ZNeu[Neu3, 1] + CW*ZNeu[Neu3, 2])*(SW*ZNeuC[Neu3, 1] + 
    CW*ZNeuC[Neu3, 2]))/(8*CW2*Pi*SW2)
