(Alfa/(2*Pi*SW2) + Alfa/(8*CW2*Pi*SW2) + (Alfa*(-4 + SW2^(-1) + 4*SW2))/
   (8*CW2*Pi) + (Alfa*B0i[bb1, 0, 0, MW2])/(Pi*SW2) + 
  (Alfa*B0i[bb1, 0, 0, MZ2])/(4*CW2*Pi*SW2) + 
  (Alfa*(-4/CW2 + 1/(CW2*SW2) + (4*SW2)/CW2)*B0i[bb1, 0, 0, MZ2])/(4*Pi))/2
