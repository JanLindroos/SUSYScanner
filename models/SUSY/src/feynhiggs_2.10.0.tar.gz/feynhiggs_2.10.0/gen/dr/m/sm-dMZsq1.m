-(Alfa*CW2*MZ2)/(6*Pi*SW2) + (Alfa*(-2 + (9*CW2)/SW2 + SW2/CW2)*A0[MW2])/
  (8*Pi) + (Alfa*(A0[MH2] + A0[MZ2]))/(16*CW2*Pi*SW2) + 
 (Alfa*MW2*B0i[bb0, MZ2, MH2, MZ2])/(4*CW2^2*Pi*SW2) + 
 ((-5*Alfa*CW2*MZ2)/(4*Pi*SW2) + (Alfa*MW2*(-(CW2/SW2) + SW2/CW2))/(2*Pi))*
  B0i[bb0, MZ2, MW2, MW2] - (Alfa*B0i[bb00, MZ2, MH2, MZ2])/(4*CW2*Pi*SW2) - 
 (Alfa*(-2 + (9*CW2)/SW2 + SW2/CW2)*B0i[bb00, MZ2, MW2, MW2])/(4*Pi) - 
 (Alfa*CW2*MZ2*B0i[bb1, MZ2, MW2, MW2])/(2*Pi*SW2)
