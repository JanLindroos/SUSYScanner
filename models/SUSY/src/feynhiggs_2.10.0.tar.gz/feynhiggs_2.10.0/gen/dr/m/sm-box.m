-(MW2*SW2*(((2*Alfa2*(1 + (1 - 2*SW2)^2))/(CW2*MW2*(-MW2 + MZ2)*SW2^2) - 
      (Alfa2*Dminus4*(1 + (1 - 2*SW2)^2))/(CW2*MW2*(-MW2 + MZ2)*SW2^2) - 
      (Alfa2*Dminus4^2*(1 + (1 - 2*SW2)^2))/(2*CW2*MW2*(-MW2 + MZ2)*SW2^2) + 
      (16*(Alfa2 - 2*Alfa2*SW2))/(CW2*MW2*(-MW2 + MZ2)*SW2^2) + 
      (8*Dminus4*(Alfa2 - 2*Alfa2*SW2))/(CW2*MW2*(-MW2 + MZ2)*SW2^2) + 
      (Dminus4^2*(Alfa2 - 2*Alfa2*SW2))/(CW2*MW2*(-MW2 + MZ2)*SW2^2))*
     A0[MW2] + ((-2*Alfa2*Dminus4^2*(MW2 + MZ2))/(CW2*MW2^2*MZ2) - 
      (2*Alfa2*MZ2*(1 + (1 - 2*SW2)^2))/(CW2*MW2^2*(-MW2 + MZ2)*SW2^2) + 
      (Alfa2*Dminus4*MZ2*(1 + (1 - 2*SW2)^2))/(CW2*MW2^2*(-MW2 + MZ2)*
        SW2^2) + (Alfa2*Dminus4^2*MZ2*(1 + (1 - 2*SW2)^2))/
       (2*CW2*MW2^2*(-MW2 + MZ2)*SW2^2) - (16*MZ2*(Alfa2 - 2*Alfa2*SW2))/
       (CW2*MW2^2*(-MW2 + MZ2)*SW2^2) - (8*Dminus4*MZ2*(Alfa2 - 2*Alfa2*SW2))/
       (CW2*MW2^2*(-MW2 + MZ2)*SW2^2) - (Dminus4^2*MZ2*(Alfa2 - 2*Alfa2*SW2))/
       (CW2*MW2^2*(-MW2 + MZ2)*SW2^2) + 
      (2*Alfa2*(MW2 + MZ2)*(10 - 20*SW2 + 4*SW2^2))/(CW2*MW2^2*MZ2*SW2^2) - 
      (Alfa2*Dminus4*(MW2 + MZ2)*(-6 + 12*SW2 + 4*SW2^2))/
       (CW2*MW2^2*MZ2*SW2^2))*A0[MZ2]))/(8*Alfa*D*Pi)
