(Alfa*((4*CBA2*CW2*(3*(MA02 + Mh02 + MHH2)*MW2 - 
        (3*CW2*(Mh02 + MHH2 + MHp2) + (-1 + CW2)*MW2)*MZ2) + 
      4*CW2*(2*CW2^2*(3*MW2*(MHp2 + 9*MW2) + 5*MW2*MZ2 - 12*MZ2^2) + 
        MW2*(3*(MA02 + Mh02 + MHH2) + MZ2)*SBA2 - 
        CW2*MZ2*(3*MA02 + 3*MHp2 + 37*MW2 + 3*MZ2 + 
          (3*(Mh02 + MHH2 + MHp2) + MW2)*SBA2)) + 
      CW2*(-48*CW2*MW2*(MHp2 + MW2) + (3*(MA02 + Mh02 + MHH2 + 2*MHp2) + 
          10*(17 - 20*CW2)*MW2)*MZ2 + 3*(1 + 8*CW2)*MZ2^2)*SW2 + 
      4*CW2*MW2*(6*MHp2 + 78*MW2 + 143*MZ2)*SW2^2 + 36*MW2*(8*MW2 + 3*MZ2)*
       SW2^3)/(CW2*MW2*MZ2*SW2^2) + 
    (6*((MA02 - MHp2)*(CBA2*MW2^2*(MA02 - Mh02 + MZ2) + 
         MZ2*(-3*MW2^2 + CW2*(-MA02 + MHp2 + 2*MW2)*MZ2) + 
         MW2^2*(MA02 - MHH2 + MZ2)*SBA2) + 
       ((MA02 - MHp2)^2 - (2*MA02 + MHp2)*MW2)*MZ2^2*SW2)*A0[MA02])/
     ((MA02 - MHp2)*MW2^2*MZ2^2*SW2^2) + 
    (6*(CBA2*(Mh02 - MW2)*((Mh02 - MHp2)*((MA02 - Mh02)*MW2^2 - MW2^2*MZ2 + 
           CW2*(Mh02 - MHp2 + MW2)*MZ2^2) - ((Mh02 - MHp2)^2 - 
           (2*Mh02 + MHp2)*MW2)*MZ2^2*SW2) + (Mh02 - MHp2)*
        (-((Mh02 - MW2)*(-3*MW2*MZ2*(MW2 - CW2*MZ2) + 
            Mh02*(MW2^2 - CW2*MZ2^2)*SBA2)) - (Mh02^2 - 4*Mh02*MW2 + 
           12*MW2^2)*MZ2^2*SBA2*SW2))*A0[Mh02])/((Mh02 - MHp2)*MW2^2*
      (-Mh02 + MW2)*MZ2^2*SW2^2) - 
    (6*(CBA2*(MHH2 - MHp2)*(MHH2*(MHH2 - MW2)*(MW2^2 - CW2*MZ2^2) + 
         (MHH2^2 - 4*MHH2*MW2 + 12*MW2^2)*MZ2^2*SW2) + 
       (MHH2 - MW2)*((MHH2 - MHp2)*(-(CW2*MW2*MZ2^2*(-3 + SBA2)) + 
           CW2*(-MHH2 + MHp2)*MZ2^2*SBA2 + MW2^2*(-3*MZ2 + 
             (-MA02 + MHH2 + MZ2)*SBA2)) + ((MHH2 - MHp2)^2 - 
           (2*MHH2 + MHp2)*MW2)*MZ2^2*SBA2*SW2))*A0[MHH2])/
     ((MHH2 - MHp2)*MW2^2*(-MHH2 + MW2)*MZ2^2*SW2^2) + 
    6*(4/MHp2 + (CW2*(MA02 + CBA2*Mh02 + 4*MW2))/(MW2^2*SW2^2) + 
      (CW2*MHH2*SBA2)/(MW2^2*SW2^2) - (4*(CW2 - SW2)^2)/(MZ2*SW2^2) - 
      MA02/(MW2^2*SW2) - (CBA2*Mh02)/(MW2^2*SW2) - 2/(MW2*SW2) - 
      (2*CBA2)/(MW2*SW2) - (MHH2*SBA2)/(MW2^2*SW2) - (2*SBA2)/(MW2*SW2) + 
      (2*MHp2*(-CW2 + SW2))/(MW2^2*SW2^2) + 
      (3*MA02)/(MA02*MW2*SW2 - MHp2*MW2*SW2) + (3*CBA2*Mh02)/
       (Mh02*MW2*SW2 - MHp2*MW2*SW2) + (3*MHH2*SBA2)/
       (MHH2*MW2*SW2 - MHp2*MW2*SW2))*A0[MHp2] + 
    (6*(4*CW2^3*(Mh02 - MW2)*(-MHH2 + MW2)*(9*MW2 - 2*MZ2)*(MW2 - MZ2)*
        (MW2 + MZ2) + CW2^2*(Mh02 - MW2)*(MHH2 - MW2)*
        ((MW2 - MZ2)*MZ2*(CBA2*(MHH2 - 2*MW2) + MZ2 - 2*MW2*(-20 + SBA2) + 
           Mh02*SBA2) + 8*(MW2^3 - 13*MW2^2*MZ2 + 5*MW2*MZ2^2 + MZ2^3)*SW2) + 
       CW2*SW2*(-(CBA2*(Mh02 - MW2)*(MHH2^2 - 4*MHH2*MW2 + 12*MW2^2)*
           (MW2 - MZ2)*MZ2) + (MHH2 - MW2)*((Mh02 - MW2)*MZ2*
            (-86*MW2^2 + 10*MW2*MZ2 + MZ2^2) + (Mh02^2 - 4*Mh02*MW2 + 
             12*MW2^2)*MZ2*(-MW2 + MZ2)*SBA2 + 4*MW2*(-Mh02 + MW2)*
            (13*MW2^2 - 11*MW2*MZ2 - 20*MZ2^2)*SW2)) + 
       6*(Mh02 - MW2)*MW2^2*(-MHH2 + MW2)*SW2*(8*MW2*SW2^2 + 
         MZ2*(-5 + 2*(5 - 6*SW2)*SW2)))*A0[MW2])/(CW2*MW2^2*(-Mh02 + MW2)*
      (-MHH2 + MW2)*(MW2 - MZ2)*MZ2*SW2^2) + 
    (6*(-(CW2*(MW2 - MZ2)*(CBA2*MW2^2*(MHH2 - 2*MZ2) - 3*CW2*(1 + 8*CW2)*MW2*
           MZ2^2 + CW2*(1 + 8*CW2)*MZ2^3 + MW2^2*(3*MZ2 + Mh02*SBA2 - 
            2*MZ2*SBA2))) + MZ2*(-30*MW2^3 + 12*CW2*(6 + CW2)*MW2^2*MZ2 + 
         4*CW2*(1 + 11*CW2)*MW2*MZ2^2 - CW2*(1 + 8*CW2)*MZ2^3)*SW2 + 
       12*MW2^2*MZ2*(5*MW2 - 6*CW2*MZ2)*SW2^2 - 24*MW2^3*MZ2*SW2^3)*A0[MZ2])/
     (CW2*MW2^2*(MW2 - MZ2)*MZ2^2*SW2^2) + 
    (6*(MA02^2 + (MHp2 - MW2)^2 - 2*MA02*(MHp2 + MW2))*(CW2 - SW2)*
      B0[MW2, MA02, MHp2])/(MW2^2*SW2^2) + 
    (6*CBA2*(Mh02^2 + (MHp2 - MW2)^2 - 2*Mh02*(MHp2 + MW2))*(CW2 - SW2)*
      B0[MW2, Mh02, MHp2])/(MW2^2*SW2^2) + 
    (6*(Mh02^2 - 4*Mh02*MW2 + 12*MW2^2)*SBA2*(CW2 - SW2)*B0[MW2, Mh02, MW2])/
     (MW2^2*SW2^2) + (6*(MHH2^2 + (MHp2 - MW2)^2 - 2*MHH2*(MHp2 + MW2))*SBA2*
      (CW2 - SW2)*B0[MW2, MHH2, MHp2])/(MW2^2*SW2^2) + 
    (6*CBA2*(MHH2^2 - 4*MHH2*MW2 + 12*MW2^2)*(CW2 - SW2)*B0[MW2, MHH2, MW2])/
     (MW2^2*SW2^2) - (6*(CW2 - SW2)*
      (CW2*(60*CW2*MW2^2 + 4*(1 + 11*CW2)*MW2*MZ2 - (1 + 8*CW2)*MZ2^2) - 
       12*MW2^2*SW2^2)*B0[MW2, MW2, MZ2])/(CW2*MW2^2*SW2^2) - 
    (6*CBA2*(MA02^2 + (Mh02 - MZ2)^2 - 2*MA02*(Mh02 + MZ2))*
      B0[MZ2, MA02, Mh02])/(MZ2^2*SW2^2) - 
    (6*(MA02^2 + (MHH2 - MZ2)^2 - 2*MA02*(MHH2 + MZ2))*SBA2*
      B0[MZ2, MA02, MHH2])/(MZ2^2*SW2^2) - 
    (6*(CW2*Mh02*(Mh02 - 4*MZ2) + 12*MW2*MZ2)*SBA2*B0[MZ2, Mh02, MZ2])/
     (CW2*MZ2^2*SW2^2) - (6*CBA2*(CW2*MHH2*(MHH2 - 4*MZ2) + 12*MW2*MZ2)*
      B0[MZ2, MHH2, MZ2])/(CW2*MZ2^2*SW2^2) + 
    (6*(4*MHp2 - MZ2)*(CW2 - SW2)^2*B0[MZ2, MHp2, MHp2])/(MZ2*SW2^2) + 
    (6*(CW2^2*(60*MW2 + 39*MZ2) + 2*CW2*(-4*MW2 + MZ2)*SW2 - 
       (20*MW2 + MZ2)*SW2^2)*B0[MZ2, MW2, MW2])/(MZ2*SW2^2)))/(288*Pi) + 
 SumOver[Gen3, 3]*
  (-(Alfa*(6*(2*MW2 - 3*CW2*MZ2)*A0[MSf2[1, 1, Gen3]] + 
       MW2*(2*(MZ2 - 6*MSf2[1, 1, Gen3]) + 3*B0[MZ2, MSf2[1, 1, Gen3], 
           MSf2[1, 1, Gen3]]*(MZ2 - 4*MSf2[1, 1, Gen3]))))/
    (144*MW2*MZ2*Pi*SW2^2) + SumOver[Sfe3, 2]*
    ((-6*Alfa*B0[0, MSf2[1, 1, Gen3], MSf2[Sfe3, 2, Gen3]]*
        (MSf2[1, 1, Gen3]*(MW2*(CW2 + 2*SW2) + (CW2 - SW2)*
            MSf2[1, 1, Gen3]) - (CW2 - SW2)*(MW2 + 2*MSf2[1, 1, Gen3])*
          MSf2[Sfe3, 2, Gen3] + (CW2 - SW2)*MSf2[Sfe3, 2, Gen3]^2)*
        USf[Sfe3, 1, 2, Gen3]*USfC[Sfe3, 1, 2, Gen3] + 
       6*Alfa*(CW2 - SW2)*B0[MW2, MSf2[1, 1, Gen3], MSf2[Sfe3, 2, Gen3]]*
        (MSf2[1, 1, Gen3]^2 + (MW2 - MSf2[Sfe3, 2, Gen3])^2 - 
         2*MSf2[1, 1, Gen3]*(MW2 + MSf2[Sfe3, 2, Gen3]))*
        USf[Sfe3, 1, 2, Gen3]*USfC[Sfe3, 1, 2, Gen3] + 
       MW2*(-32*Alfa*MW2*SW2^2 + Alfa*(4*MW2*(CW2 - SW2) - 
           3*(4*CW2 - SW2)*(MSf2[1, 1, Gen3] + MSf2[Sfe3, 2, Gen3]))*
          USf[Sfe3, 1, 2, Gen3]*USfC[Sfe3, 1, 2, Gen3]) + 
       (6*Alfa*MW2*A0[MSf2[Sfe3, 2, Gen3]]*(2*MW2*MZ2*SW2^2 - 
          MSf2[Sfe3, 2, Gen3]*((3*MW2*(1 - 2*SW2)^2 + MZ2*(-CW2 + SW2))*
             USf[Sfe3, 1, 2, Gen3]*USfC[Sfe3, 1, 2, Gen3] + 
            12*MW2*SW2^2*USf[Sfe3, 2, 2, Gen3]*USfC[Sfe3, 2, 2, Gen3])))/
        (MZ2*MSf2[Sfe3, 2, Gen3]) + (2*Alfa*MW2*A0[MSf2[Sfe3, 3, Gen3]]*
         (8*MW2*MZ2*SW2^2 - 3*MSf2[Sfe3, 3, Gen3]*
           ((-9*CW2*MZ2 + MW2*(3 - 4*SW2)^2)*USf[Sfe3, 1, 3, Gen3]*
             USfC[Sfe3, 1, 3, Gen3] + 16*MW2*SW2^2*USf[Sfe3, 2, 3, Gen3]*
             USfC[Sfe3, 2, 3, Gen3])))/(MZ2*MSf2[Sfe3, 3, Gen3]) + 
       (2*Alfa*MW2*A0[MSf2[Sfe3, 4, Gen3]]*(2*MW2*MZ2*SW2^2 - 
          3*MSf2[Sfe3, 4, Gen3]*((-9*CW2*MZ2 + MW2*(3 - 2*SW2)^2)*
             USf[Sfe3, 1, 4, Gen3]*USfC[Sfe3, 1, 4, Gen3] + 
            4*MW2*SW2^2*USf[Sfe3, 2, 4, Gen3]*USfC[Sfe3, 2, 4, Gen3])))/
        (MZ2*MSf2[Sfe3, 4, Gen3]))/(144*MW2^2*Pi*SW2^2) + 
     (Alfa*SumOver[Sfe4, 2]*((36*CW2*(MW2 - 3*MSf2[Sfe3, 3, Gen3] - 
           3*MSf2[Sfe4, 4, Gen3])*USf[Sfe3, 1, 3, Gen3]*USf[Sfe4, 1, 4, Gen3]*
          USfC[Sfe3, 1, 3, Gen3]*USfC[Sfe4, 1, 4, Gen3])/MW2 - 
        (81*SW2*(MSf2[Sfe3, 3, Gen3] + MSf2[Sfe4, 4, Gen3])*
          USf[Sfe3, 1, 3, Gen3]*USf[Sfe4, 1, 4, Gen3]*USfC[Sfe3, 1, 3, Gen3]*
          USfC[Sfe4, 1, 4, Gen3])/MW2 - 
        (54*B0[0, MSf2[Sfe3, 3, Gen3], MSf2[Sfe4, 4, Gen3]]*
          (MSf2[Sfe3, 3, Gen3]*(MW2*(CW2 + 2*SW2) + (CW2 - SW2)*
              MSf2[Sfe3, 3, Gen3]) - (CW2 - SW2)*(MW2 + 
             2*MSf2[Sfe3, 3, Gen3])*MSf2[Sfe4, 4, Gen3] + 
           (CW2 - SW2)*MSf2[Sfe4, 4, Gen3]^2)*USf[Sfe3, 1, 3, Gen3]*
          USf[Sfe4, 1, 4, Gen3]*USfC[Sfe3, 1, 3, Gen3]*USfC[Sfe4, 1, 4, 
           Gen3])/MW2^2 + (54*(CW2 - SW2)*B0[MW2, MSf2[Sfe3, 3, Gen3], 
           MSf2[Sfe4, 4, Gen3]]*(MSf2[Sfe3, 3, Gen3]^2 + 
           (MW2 - MSf2[Sfe4, 4, Gen3])^2 - 2*MSf2[Sfe3, 3, Gen3]*
            (MW2 + MSf2[Sfe4, 4, Gen3]))*USf[Sfe3, 1, 3, Gen3]*
          USf[Sfe4, 1, 4, Gen3]*USfC[Sfe3, 1, 3, Gen3]*USfC[Sfe4, 1, 4, 
           Gen3])/MW2^2 + (36*SW2*(-MW2 + 3*(MSf2[Sfe3, 3, Gen3] + 
             MSf2[Sfe4, 4, Gen3]))*USf[Sfe3, 1, 3, Gen3]*
          USf[Sfe4, 1, 4, Gen3]*USfC[Sfe3, 1, 3, Gen3]*USfC[Sfe4, 1, 4, 
           Gen3])/MW2 + (18*A0[MSf2[Sfe4, 2, Gen3]]*
          ((-1 + 2*SW2)*USf[Sfe4, 1, 2, Gen3]*USfC[Sfe3, 1, 2, Gen3] + 
           2*SW2*USf[Sfe4, 2, 2, Gen3]*USfC[Sfe3, 2, 2, Gen3])*
          ((-1 + 2*SW2)*USf[Sfe3, 1, 2, Gen3]*USfC[Sfe4, 1, 2, Gen3] + 
           2*SW2*USf[Sfe3, 2, 2, Gen3]*USfC[Sfe4, 2, 2, Gen3]))/MZ2 + 
        (9*B0[0, MSf2[Sfe3, 2, Gen3], MSf2[Sfe4, 2, Gen3]]*
          (MSf2[Sfe3, 2, Gen3] - MSf2[Sfe4, 2, Gen3])*
          (MZ2 + MSf2[Sfe3, 2, Gen3] - MSf2[Sfe4, 2, Gen3])*
          ((-1 + 2*SW2)*USf[Sfe4, 1, 2, Gen3]*USfC[Sfe3, 1, 2, Gen3] + 
           2*SW2*USf[Sfe4, 2, 2, Gen3]*USfC[Sfe3, 2, 2, Gen3])*
          ((-1 + 2*SW2)*USf[Sfe3, 1, 2, Gen3]*USfC[Sfe4, 1, 2, Gen3] + 
           2*SW2*USf[Sfe3, 2, 2, Gen3]*USfC[Sfe4, 2, 2, Gen3]))/MZ2^2 - 
        (9*B0[MZ2, MSf2[Sfe3, 2, Gen3], MSf2[Sfe4, 2, Gen3]]*
          (MSf2[Sfe3, 2, Gen3]^2 + (MZ2 - MSf2[Sfe4, 2, Gen3])^2 - 
           2*MSf2[Sfe3, 2, Gen3]*(MZ2 + MSf2[Sfe4, 2, Gen3]))*
          ((-1 + 2*SW2)*USf[Sfe4, 1, 2, Gen3]*USfC[Sfe3, 1, 2, Gen3] + 
           2*SW2*USf[Sfe4, 2, 2, Gen3]*USfC[Sfe3, 2, 2, Gen3])*
          ((-1 + 2*SW2)*USf[Sfe3, 1, 2, Gen3]*USfC[Sfe4, 1, 2, Gen3] + 
           2*SW2*USf[Sfe3, 2, 2, Gen3]*USfC[Sfe4, 2, 2, Gen3]))/MZ2^2 + 
        (6*(-MZ2 + 3*(MSf2[Sfe3, 2, Gen3] + MSf2[Sfe4, 2, Gen3]))*
          ((-1 + 2*SW2)*USf[Sfe4, 1, 2, Gen3]*USfC[Sfe3, 1, 2, Gen3] + 
           2*SW2*USf[Sfe4, 2, 2, Gen3]*USfC[Sfe3, 2, 2, Gen3])*
          ((-1 + 2*SW2)*USf[Sfe3, 1, 2, Gen3]*USfC[Sfe4, 1, 2, Gen3] + 
           2*SW2*USf[Sfe3, 2, 2, Gen3]*USfC[Sfe4, 2, 2, Gen3]))/MZ2 + 
        (6*A0[MSf2[Sfe4, 3, Gen3]]*((-3 + 4*SW2)*USf[Sfe4, 1, 3, Gen3]*
            USfC[Sfe3, 1, 3, Gen3] + 4*SW2*USf[Sfe4, 2, 3, Gen3]*
            USfC[Sfe3, 2, 3, Gen3])*((-3 + 4*SW2)*USf[Sfe3, 1, 3, Gen3]*
            USfC[Sfe4, 1, 3, Gen3] + 4*SW2*USf[Sfe3, 2, 3, Gen3]*
            USfC[Sfe4, 2, 3, Gen3]))/MZ2 + 
        (3*B0[0, MSf2[Sfe3, 3, Gen3], MSf2[Sfe4, 3, Gen3]]*
          (MSf2[Sfe3, 3, Gen3] - MSf2[Sfe4, 3, Gen3])*
          (MZ2 + MSf2[Sfe3, 3, Gen3] - MSf2[Sfe4, 3, Gen3])*
          ((-3 + 4*SW2)*USf[Sfe4, 1, 3, Gen3]*USfC[Sfe3, 1, 3, Gen3] + 
           4*SW2*USf[Sfe4, 2, 3, Gen3]*USfC[Sfe3, 2, 3, Gen3])*
          ((-3 + 4*SW2)*USf[Sfe3, 1, 3, Gen3]*USfC[Sfe4, 1, 3, Gen3] + 
           4*SW2*USf[Sfe3, 2, 3, Gen3]*USfC[Sfe4, 2, 3, Gen3]))/MZ2^2 - 
        (3*B0[MZ2, MSf2[Sfe3, 3, Gen3], MSf2[Sfe4, 3, Gen3]]*
          (MSf2[Sfe3, 3, Gen3]^2 + (MZ2 - MSf2[Sfe4, 3, Gen3])^2 - 
           2*MSf2[Sfe3, 3, Gen3]*(MZ2 + MSf2[Sfe4, 3, Gen3]))*
          ((-3 + 4*SW2)*USf[Sfe4, 1, 3, Gen3]*USfC[Sfe3, 1, 3, Gen3] + 
           4*SW2*USf[Sfe4, 2, 3, Gen3]*USfC[Sfe3, 2, 3, Gen3])*
          ((-3 + 4*SW2)*USf[Sfe3, 1, 3, Gen3]*USfC[Sfe4, 1, 3, Gen3] + 
           4*SW2*USf[Sfe3, 2, 3, Gen3]*USfC[Sfe4, 2, 3, Gen3]))/MZ2^2 + 
        (2*(-MZ2 + 3*(MSf2[Sfe3, 3, Gen3] + MSf2[Sfe4, 3, Gen3]))*
          ((-3 + 4*SW2)*USf[Sfe4, 1, 3, Gen3]*USfC[Sfe3, 1, 3, Gen3] + 
           4*SW2*USf[Sfe4, 2, 3, Gen3]*USfC[Sfe3, 2, 3, Gen3])*
          ((-3 + 4*SW2)*USf[Sfe3, 1, 3, Gen3]*USfC[Sfe4, 1, 3, Gen3] + 
           4*SW2*USf[Sfe3, 2, 3, Gen3]*USfC[Sfe4, 2, 3, Gen3]))/MZ2 + 
        (3*B0[0, MSf2[Sfe3, 4, Gen3], MSf2[Sfe4, 4, Gen3]]*
          (MSf2[Sfe3, 4, Gen3] - MSf2[Sfe4, 4, Gen3])*
          (MZ2 + MSf2[Sfe3, 4, Gen3] - MSf2[Sfe4, 4, Gen3])*
          ((-3 + 2*SW2)*USf[Sfe4, 1, 4, Gen3]*USfC[Sfe3, 1, 4, Gen3] + 
           2*SW2*USf[Sfe4, 2, 4, Gen3]*USfC[Sfe3, 2, 4, Gen3])*
          ((-3 + 2*SW2)*USf[Sfe3, 1, 4, Gen3]*USfC[Sfe4, 1, 4, Gen3] + 
           2*SW2*USf[Sfe3, 2, 4, Gen3]*USfC[Sfe4, 2, 4, Gen3]))/MZ2^2 - 
        (3*B0[MZ2, MSf2[Sfe3, 4, Gen3], MSf2[Sfe4, 4, Gen3]]*
          (MSf2[Sfe3, 4, Gen3]^2 + (MZ2 - MSf2[Sfe4, 4, Gen3])^2 - 
           2*MSf2[Sfe3, 4, Gen3]*(MZ2 + MSf2[Sfe4, 4, Gen3]))*
          ((-3 + 2*SW2)*USf[Sfe4, 1, 4, Gen3]*USfC[Sfe3, 1, 4, Gen3] + 
           2*SW2*USf[Sfe4, 2, 4, Gen3]*USfC[Sfe3, 2, 4, Gen3])*
          ((-3 + 2*SW2)*USf[Sfe3, 1, 4, Gen3]*USfC[Sfe4, 1, 4, Gen3] + 
           2*SW2*USf[Sfe3, 2, 4, Gen3]*USfC[Sfe4, 2, 4, Gen3]))/MZ2^2 + 
        (2*(-MZ2 + 3*(MSf2[Sfe3, 4, Gen3] + MSf2[Sfe4, 4, Gen3]))*
          ((-3 + 2*SW2)*USf[Sfe4, 1, 4, Gen3]*USfC[Sfe3, 1, 4, Gen3] + 
           2*SW2*USf[Sfe4, 2, 4, Gen3]*USfC[Sfe3, 2, 4, Gen3])*
          ((-3 + 2*SW2)*USf[Sfe3, 1, 4, Gen3]*USfC[Sfe4, 1, 4, Gen3] + 
           2*SW2*USf[Sfe3, 2, 4, Gen3]*USfC[Sfe4, 2, 4, Gen3]))/MZ2 + 
        (6*A0[MSf2[Sfe4, 4, Gen3]]*(-9*MZ2*(2*CW2 + SW2)*USf[Sfe3, 1, 3, 
             Gen3]*USf[Sfe4, 1, 4, Gen3]*USfC[Sfe3, 1, 3, Gen3]*
            USfC[Sfe4, 1, 4, Gen3] + MW2*((-3 + 2*SW2)*USf[Sfe4, 1, 4, Gen3]*
              USfC[Sfe3, 1, 4, Gen3] + 2*SW2*USf[Sfe4, 2, 4, Gen3]*
              USfC[Sfe3, 2, 4, Gen3])*((-3 + 2*SW2)*USf[Sfe3, 1, 4, Gen3]*
              USfC[Sfe4, 1, 4, Gen3] + 2*SW2*USf[Sfe3, 2, 4, Gen3]*
              USfC[Sfe4, 2, 4, Gen3])))/(MW2*MZ2)))/(432*Pi*SW2^2))) - 
 (Alfa*SumOver[Neu3, 4]*SumOver[Sfe3, 2]*
   (B0[0, MNeu2[Neu3], MSf2[Sfe3, 2, 1]]*USf[Sfe3, 1, 2, 1]*
     USfC[Sfe3, 1, 2, 1] + DB0[0, MNeu2[Neu3], MSf2[Sfe3, 2, 1]]*
     (MNeu2[Neu3] - MSf2[Sfe3, 2, 1])*USf[Sfe3, 1, 2, 1]*
     USfC[Sfe3, 1, 2, 1] + (B0[0, MNeu2[Neu3], MSf2[Sfe3, 2, 2]] + 
      DB0[0, MNeu2[Neu3], MSf2[Sfe3, 2, 2]]*(MNeu2[Neu3] - MSf2[Sfe3, 2, 2]))*
     USf[Sfe3, 1, 2, 2]*USfC[Sfe3, 1, 2, 2])*(SW*ZNeu[Neu3, 1] + 
    CW*ZNeu[Neu3, 2])*(SW*ZNeuC[Neu3, 1] + CW*ZNeuC[Neu3, 2]))/
  (32*CW2*Pi*SW2) + SumOver[Cha3, 2]*
  (-(Alfa*SumOver[Sfe3, 2]*UCha[Cha3, 1]*UChaC[Cha3, 1]*
      (B0[0, MCha2[Cha3], MSf2[Sfe3, 2, 1]]*USf[Sfe3, 1, 2, 1]*
        USfC[Sfe3, 1, 2, 1] + DB0[0, MCha2[Cha3], MSf2[Sfe3, 2, 1]]*
        (MCha2[Cha3] - MSf2[Sfe3, 2, 1])*USf[Sfe3, 1, 2, 1]*
        USfC[Sfe3, 1, 2, 1] + (B0[0, MCha2[Cha3], MSf2[Sfe3, 2, 2]] + 
         DB0[0, MCha2[Cha3], MSf2[Sfe3, 2, 2]]*(MCha2[Cha3] - 
           MSf2[Sfe3, 2, 2]))*USf[Sfe3, 1, 2, 2]*USfC[Sfe3, 1, 2, 2]))/
    (16*Pi*SW2) + (Alfa*(16*SW2*A0[MCha2[Cha3]] - 
      MCha2[Cha3]*(16*SW2 + 3*B0[0, MCha2[Cha3], MSf2[1, 1, 1]]*VCha[Cha3, 1]*
         VChaC[Cha3, 1] + 3*B0[0, MCha2[Cha3], MSf2[1, 1, 2]]*VCha[Cha3, 1]*
         VChaC[Cha3, 1] + 3*DB0[0, MCha2[Cha3], MSf2[1, 1, 1]]*MCha2[Cha3]*
         VCha[Cha3, 1]*VChaC[Cha3, 1] + 3*DB0[0, MCha2[Cha3], MSf2[1, 1, 2]]*
         MCha2[Cha3]*VCha[Cha3, 1]*VChaC[Cha3, 1] - 
        3*DB0[0, MCha2[Cha3], MSf2[1, 1, 1]]*MSf2[1, 1, 1]*VCha[Cha3, 1]*
         VChaC[Cha3, 1] - 3*DB0[0, MCha2[Cha3], MSf2[1, 1, 2]]*MSf2[1, 1, 2]*
         VCha[Cha3, 1]*VChaC[Cha3, 1])))/(48*Pi*SW2*MCha2[Cha3]) + 
   (Alfa*SumOver[Cha4, 2]*(12*MZ2*A0[MCha2[Cha4]]*
       ((SW2*IndexDelta[Cha3, Cha4] - UCha[Cha4, 1]*UChaC[Cha3, 1] - 
          (UCha[Cha4, 2]*UChaC[Cha3, 2])/2)*(SW2*IndexDelta[Cha3, Cha4] - 
          UCha[Cha3, 1]*UChaC[Cha4, 1] - (UCha[Cha3, 2]*UChaC[Cha4, 2])/2) + 
        (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha4, 1]*VChaC[Cha3, 1] - 
          (VCha[Cha4, 2]*VChaC[Cha3, 2])/2)*(SW2*IndexDelta[Cha3, Cha4] - 
          VCha[Cha3, 1]*VChaC[Cha4, 1] - (VCha[Cha3, 2]*VChaC[Cha4, 2])/2)) - 
      3*B0[0, MCha2[Cha3], MCha2[Cha4]]*(MCha2[Cha3] - MCha2[Cha4])*
       (-2*MZ2 + MCha2[Cha3] - MCha2[Cha4])*
       ((SW2*IndexDelta[Cha3, Cha4] - UCha[Cha4, 1]*UChaC[Cha3, 1] - 
          (UCha[Cha4, 2]*UChaC[Cha3, 2])/2)*(SW2*IndexDelta[Cha3, Cha4] - 
          UCha[Cha3, 1]*UChaC[Cha4, 1] - (UCha[Cha3, 2]*UChaC[Cha4, 2])/2) + 
        (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha4, 1]*VChaC[Cha3, 1] - 
          (VCha[Cha4, 2]*VChaC[Cha3, 2])/2)*(SW2*IndexDelta[Cha3, Cha4] - 
          VCha[Cha3, 1]*VChaC[Cha4, 1] - (VCha[Cha3, 2]*VChaC[Cha4, 2])/2)) - 
      2*MZ2*(-MZ2 + 3*(MCha2[Cha3] + MCha2[Cha4]))*
       ((SW2*IndexDelta[Cha3, Cha4] - UCha[Cha4, 1]*UChaC[Cha3, 1] - 
          (UCha[Cha4, 2]*UChaC[Cha3, 2])/2)*(SW2*IndexDelta[Cha3, Cha4] - 
          UCha[Cha3, 1]*UChaC[Cha4, 1] - (UCha[Cha3, 2]*UChaC[Cha4, 2])/2) + 
        (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha4, 1]*VChaC[Cha3, 1] - 
          (VCha[Cha4, 2]*VChaC[Cha3, 2])/2)*(SW2*IndexDelta[Cha3, Cha4] - 
          VCha[Cha3, 1]*VChaC[Cha4, 1] - (VCha[Cha3, 2]*VChaC[Cha4, 2])/2)) - 
      3*MZ2*B0[MZ2, MCha2[Cha3], MCha2[Cha4]]*
       (6*MCha[Cha3]*MCha[Cha4]*((SW2*IndexDelta[Cha3, Cha4] - 
            UCha[Cha4, 1]*UChaC[Cha3, 1] - (UCha[Cha4, 2]*UChaC[Cha3, 2])/2)*
           (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha4, 1]*VChaC[Cha3, 1] - 
            (VCha[Cha4, 2]*VChaC[Cha3, 2])/2) + (SW2*IndexDelta[Cha3, Cha4] - 
            UCha[Cha3, 1]*UChaC[Cha4, 1] - (UCha[Cha3, 2]*UChaC[Cha4, 2])/2)*
           (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha3, 1]*VChaC[Cha4, 1] - 
            (VCha[Cha3, 2]*VChaC[Cha4, 2])/2)) + 
        3*MZ2*((SW2*IndexDelta[Cha3, Cha4] - UCha[Cha4, 1]*UChaC[Cha3, 1] - 
            (UCha[Cha4, 2]*UChaC[Cha3, 2])/2)*(SW2*IndexDelta[Cha3, Cha4] - 
            UCha[Cha3, 1]*UChaC[Cha4, 1] - (UCha[Cha3, 2]*UChaC[Cha4, 2])/
             2) + (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha4, 1]*
             VChaC[Cha3, 1] - (VCha[Cha4, 2]*VChaC[Cha3, 2])/2)*
           (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha3, 1]*VChaC[Cha4, 1] - 
            (VCha[Cha3, 2]*VChaC[Cha4, 2])/2)) - 2*MCha2[Cha3]*
         ((SW2*IndexDelta[Cha3, Cha4] - UCha[Cha4, 1]*UChaC[Cha3, 1] - 
            (UCha[Cha4, 2]*UChaC[Cha3, 2])/2)*(SW2*IndexDelta[Cha3, Cha4] - 
            UCha[Cha3, 1]*UChaC[Cha4, 1] - (UCha[Cha3, 2]*UChaC[Cha4, 2])/
             2) + (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha4, 1]*
             VChaC[Cha3, 1] - (VCha[Cha4, 2]*VChaC[Cha3, 2])/2)*
           (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha3, 1]*VChaC[Cha4, 1] - 
            (VCha[Cha3, 2]*VChaC[Cha4, 2])/2)) + 
        3*(MCha2[Cha3] - MCha2[Cha4])*((SW2*IndexDelta[Cha3, Cha4] - 
            UCha[Cha4, 1]*UChaC[Cha3, 1] - (UCha[Cha4, 2]*UChaC[Cha3, 2])/2)*
           (SW2*IndexDelta[Cha3, Cha4] - UCha[Cha3, 1]*UChaC[Cha4, 1] - 
            (UCha[Cha3, 2]*UChaC[Cha4, 2])/2) + (SW2*IndexDelta[Cha3, Cha4] - 
            VCha[Cha4, 1]*VChaC[Cha3, 1] - (VCha[Cha4, 2]*VChaC[Cha3, 2])/2)*
           (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha3, 1]*VChaC[Cha4, 1] - 
            (VCha[Cha3, 2]*VChaC[Cha4, 2])/2)) - 
        (MZ2 + MCha2[Cha3] - MCha2[Cha4])*
         ((SW2*IndexDelta[Cha3, Cha4] - UCha[Cha4, 1]*UChaC[Cha3, 1] - 
            (UCha[Cha4, 2]*UChaC[Cha3, 2])/2)*(SW2*IndexDelta[Cha3, Cha4] - 
            UCha[Cha3, 1]*UChaC[Cha4, 1] - (UCha[Cha3, 2]*UChaC[Cha4, 2])/
             2) + (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha4, 1]*
             VChaC[Cha3, 1] - (VCha[Cha4, 2]*VChaC[Cha3, 2])/2)*
           (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha3, 1]*VChaC[Cha4, 1] - 
            (VCha[Cha3, 2]*VChaC[Cha4, 2])/2)) - 
        ((MCha2[Cha3] - MCha2[Cha4])*(MZ2 + MCha2[Cha3] - MCha2[Cha4])*
          ((SW2*IndexDelta[Cha3, Cha4] - UCha[Cha4, 1]*UChaC[Cha3, 1] - 
             (UCha[Cha4, 2]*UChaC[Cha3, 2])/2)*(SW2*IndexDelta[Cha3, Cha4] - 
             UCha[Cha3, 1]*UChaC[Cha4, 1] - (UCha[Cha3, 2]*UChaC[Cha4, 2])/
              2) + (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha4, 1]*
              VChaC[Cha3, 1] - (VCha[Cha4, 2]*VChaC[Cha3, 2])/2)*
            (SW2*IndexDelta[Cha3, Cha4] - VCha[Cha3, 1]*VChaC[Cha4, 1] - 
             (VCha[Cha3, 2]*VChaC[Cha4, 2])/2)))/MZ2)))/(36*MZ2^2*Pi*SW2^2) + 
   (Alfa*SumOver[Neu3, 4]*(3*MW2*(2*CW2 + SW2)*A0[MNeu2[Neu3]]*
       (UCha[Cha3, 1]*(2*UChaC[Cha3, 1]*ZNeu[Neu3, 2] + 
          Sqrt[2]*UChaC[Cha3, 2]*ZNeu[Neu3, 3])*ZNeuC[Neu3, 2] + 
        VCha[Cha3, 1]*(2*VChaC[Cha3, 1]*ZNeu[Neu3, 2] - 
          Sqrt[2]*VChaC[Cha3, 2]*ZNeu[Neu3, 4])*ZNeuC[Neu3, 2] + 
        UCha[Cha3, 2]*(Sqrt[2]*UChaC[Cha3, 1]*ZNeu[Neu3, 2] + 
          UChaC[Cha3, 2]*ZNeu[Neu3, 3])*ZNeuC[Neu3, 3] + 
        VCha[Cha3, 2]*(-(Sqrt[2]*VChaC[Cha3, 1]*ZNeu[Neu3, 2]) + 
          VChaC[Cha3, 2]*ZNeu[Neu3, 4])*ZNeuC[Neu3, 4]) - 
      36*CW2*MW2*A0[MCha2[Cha3]]*((UChaC[Cha3, 1]*ZNeu[Neu3, 2] + 
          (UChaC[Cha3, 2]*ZNeu[Neu3, 3])/Sqrt[2])*
         (UCha[Cha3, 1]*ZNeuC[Neu3, 2] + (UCha[Cha3, 2]*ZNeuC[Neu3, 3])/
           Sqrt[2]) + (VChaC[Cha3, 1]*ZNeu[Neu3, 2] - 
          (VChaC[Cha3, 2]*ZNeu[Neu3, 4])/Sqrt[2])*
         (VCha[Cha3, 1]*ZNeuC[Neu3, 2] - (VCha[Cha3, 2]*ZNeuC[Neu3, 4])/
           Sqrt[2])) + MW2*(4*MW2*(-CW2 + SW2) + 3*(4*CW2 - SW2)*
         (MCha2[Cha3] + MNeu2[Neu3]))*
       ((UChaC[Cha3, 1]*ZNeu[Neu3, 2] + (UChaC[Cha3, 2]*ZNeu[Neu3, 3])/
           Sqrt[2])*(UCha[Cha3, 1]*ZNeuC[Neu3, 2] + 
          (UCha[Cha3, 2]*ZNeuC[Neu3, 3])/Sqrt[2]) + 
        (VChaC[Cha3, 1]*ZNeu[Neu3, 2] - (VChaC[Cha3, 2]*ZNeu[Neu3, 4])/
           Sqrt[2])*(VCha[Cha3, 1]*ZNeuC[Neu3, 2] - 
          (VCha[Cha3, 2]*ZNeuC[Neu3, 4])/Sqrt[2])) + 
      3*(CW2 - SW2)*B0[MW2, MCha2[Cha3], MNeu2[Neu3]]*
       ((2*MW2^2 - MCha2[Cha3]^2 - MCha2[Cha3]*(MW2 - 2*MNeu2[Neu3]) - 
          MW2*MNeu2[Neu3] - MNeu2[Neu3]^2)*
         (UCha[Cha3, 1]*(2*UChaC[Cha3, 1]*ZNeu[Neu3, 2] + 
            Sqrt[2]*UChaC[Cha3, 2]*ZNeu[Neu3, 3])*ZNeuC[Neu3, 2] + 
          VCha[Cha3, 1]*(2*VChaC[Cha3, 1]*ZNeu[Neu3, 2] - 
            Sqrt[2]*VChaC[Cha3, 2]*ZNeu[Neu3, 4])*ZNeuC[Neu3, 2] + 
          UCha[Cha3, 2]*(Sqrt[2]*UChaC[Cha3, 1]*ZNeu[Neu3, 2] + 
            UChaC[Cha3, 2]*ZNeu[Neu3, 3])*ZNeuC[Neu3, 3] + 
          VCha[Cha3, 2]*(-(Sqrt[2]*VChaC[Cha3, 1]*ZNeu[Neu3, 2]) + 
            VChaC[Cha3, 2]*ZNeu[Neu3, 4])*ZNeuC[Neu3, 4]) + 
        6*MW2*MCha[Cha3]*MNeu[Neu3]*(VChaC[Cha3, 1]*ZNeu[Neu3, 2]*
           (2*UChaC[Cha3, 1]*ZNeu[Neu3, 2] + Sqrt[2]*UChaC[Cha3, 2]*
             ZNeu[Neu3, 3]) - VChaC[Cha3, 2]*(Sqrt[2]*UChaC[Cha3, 1]*
             ZNeu[Neu3, 2] + UChaC[Cha3, 2]*ZNeu[Neu3, 3])*ZNeu[Neu3, 4] + 
          VCha[Cha3, 1]*ZNeuC[Neu3, 2]*(2*UCha[Cha3, 1]*ZNeuC[Neu3, 2] + 
            Sqrt[2]*UCha[Cha3, 2]*ZNeuC[Neu3, 3]) - VCha[Cha3, 2]*
           (Sqrt[2]*UCha[Cha3, 1]*ZNeuC[Neu3, 2] + UCha[Cha3, 2]*
             ZNeuC[Neu3, 3])*ZNeuC[Neu3, 4])) + 
      6*B0[0, MCha2[Cha3], MNeu2[Neu3]]*
       (((MCha2[Cha3]*(MW2*(4*CW2 - SW2) + (CW2 - SW2)*MCha2[Cha3]) - 
           2*(MW2*(2*CW2 + SW2) + (CW2 - SW2)*MCha2[Cha3])*MNeu2[Neu3] + 
           (CW2 - SW2)*MNeu2[Neu3]^2)*(UCha[Cha3, 1]*
            (2*UChaC[Cha3, 1]*ZNeu[Neu3, 2] + Sqrt[2]*UChaC[Cha3, 2]*
              ZNeu[Neu3, 3])*ZNeuC[Neu3, 2] + VCha[Cha3, 1]*
            (2*VChaC[Cha3, 1]*ZNeu[Neu3, 2] - Sqrt[2]*VChaC[Cha3, 2]*
              ZNeu[Neu3, 4])*ZNeuC[Neu3, 2] + UCha[Cha3, 2]*
            (Sqrt[2]*UChaC[Cha3, 1]*ZNeu[Neu3, 2] + UChaC[Cha3, 2]*
              ZNeu[Neu3, 3])*ZNeuC[Neu3, 3] + VCha[Cha3, 2]*
            (-(Sqrt[2]*VChaC[Cha3, 1]*ZNeu[Neu3, 2]) + VChaC[Cha3, 2]*
              ZNeu[Neu3, 4])*ZNeuC[Neu3, 4]))/2 + 3*MW2*SW2*MCha[Cha3]*
         MNeu[Neu3]*(VChaC[Cha3, 1]*ZNeu[Neu3, 2]*
           (2*UChaC[Cha3, 1]*ZNeu[Neu3, 2] + Sqrt[2]*UChaC[Cha3, 2]*
             ZNeu[Neu3, 3]) - VChaC[Cha3, 2]*(Sqrt[2]*UChaC[Cha3, 1]*
             ZNeu[Neu3, 2] + UChaC[Cha3, 2]*ZNeu[Neu3, 3])*ZNeu[Neu3, 4] + 
          VCha[Cha3, 1]*ZNeuC[Neu3, 2]*(2*UCha[Cha3, 1]*ZNeuC[Neu3, 2] + 
            Sqrt[2]*UCha[Cha3, 2]*ZNeuC[Neu3, 3]) - VCha[Cha3, 2]*
           (Sqrt[2]*UCha[Cha3, 1]*ZNeuC[Neu3, 2] + UCha[Cha3, 2]*
             ZNeuC[Neu3, 3])*ZNeuC[Neu3, 4]))))/(72*MW2^2*Pi*SW2^2)) + 
 SumOver[Neu3, 4]*((Alfa*(B0[0, MNeu2[Neu3], MSf2[1, 1, 1]] + 
      B0[0, MNeu2[Neu3], MSf2[1, 1, 2]] + DB0[0, MNeu2[Neu3], MSf2[1, 1, 1]]*
       (MNeu2[Neu3] - MSf2[1, 1, 1]) + DB0[0, MNeu2[Neu3], MSf2[1, 1, 2]]*
       (MNeu2[Neu3] - MSf2[1, 1, 2]))*(SW*ZNeu[Neu3, 1] - CW*ZNeu[Neu3, 2])*
     (-(SW*ZNeuC[Neu3, 1]) + CW*ZNeuC[Neu3, 2]))/(32*CW2*Pi*SW2) + 
   (Alfa*SumOver[Neu4, 4]*(12*MZ2*A0[MNeu2[Neu4]]*
       (ZNeu[Neu4, 3]*ZNeuC[Neu3, 3] - ZNeu[Neu4, 4]*ZNeuC[Neu3, 4])*
       (ZNeu[Neu3, 3]*ZNeuC[Neu4, 3] - ZNeu[Neu3, 4]*ZNeuC[Neu4, 4]) + 
      2*MZ2*(MZ2 - 3*MNeu2[Neu3] - 3*MNeu2[Neu4])*
       (ZNeu[Neu4, 3]*ZNeuC[Neu3, 3] - ZNeu[Neu4, 4]*ZNeuC[Neu3, 4])*
       (ZNeu[Neu3, 3]*ZNeuC[Neu4, 3] - ZNeu[Neu3, 4]*ZNeuC[Neu4, 4]) + 
      3*B0[0, MNeu2[Neu3], MNeu2[Neu4]]*(MNeu2[Neu3] - MNeu2[Neu4])*
       (2*MZ2 - MNeu2[Neu3] + MNeu2[Neu4])*(ZNeu[Neu4, 3]*ZNeuC[Neu3, 3] - 
        ZNeu[Neu4, 4]*ZNeuC[Neu3, 4])*(ZNeu[Neu3, 3]*ZNeuC[Neu4, 3] - 
        ZNeu[Neu3, 4]*ZNeuC[Neu4, 4]) + 3*B0[MZ2, MNeu2[Neu3], MNeu2[Neu4]]*
       (-((2*MZ2^2 - MNeu2[Neu3]^2 - MNeu2[Neu3]*(MZ2 - 2*MNeu2[Neu4]) - 
           MZ2*MNeu2[Neu4] - MNeu2[Neu4]^2)*(ZNeu[Neu4, 3]*ZNeuC[Neu3, 3] - 
           ZNeu[Neu4, 4]*ZNeuC[Neu3, 4])*(ZNeu[Neu3, 3]*ZNeuC[Neu4, 3] - 
           ZNeu[Neu3, 4]*ZNeuC[Neu4, 4])) + 3*MZ2*MNeu[Neu3]*MNeu[Neu4]*
         ((ZNeu[Neu4, 3]*ZNeuC[Neu3, 3] - ZNeu[Neu4, 4]*ZNeuC[Neu3, 4])^2 + 
          (ZNeu[Neu3, 3]*ZNeuC[Neu4, 3] - ZNeu[Neu3, 4]*ZNeuC[Neu4, 4])^2))))/
    (144*MZ2^2*Pi*SW2^2)) + (Alfa*SumOver[Neu5, 4]*SumOver[Sfe5, 2]*
   ((2*A0[MSf2[1, 1, 1]]*MSf2[1, 1, 1]*USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*
      (SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*(SW*ZNeuC[Neu5, 1] - 
       CW*ZNeuC[Neu5, 2]))/((MNeu2[Neu5] - MSf2[1, 1, 1])*
      (MSf2[1, 1, 1] - MSf2[Sfe5, 2, 1])) + 
    (2*A0[MSf2[Sfe5, 2, 1]]*MSf2[Sfe5, 2, 1]*USf[Sfe5, 1, 2, 1]*
      USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*
      (SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2]))/
     ((MNeu2[Neu5] - MSf2[Sfe5, 2, 1])*(-MSf2[1, 1, 1] + MSf2[Sfe5, 2, 1])) - 
    (2*A0[MSf2[1, 1, 2]]*MSf2[1, 1, 2]*USf[Sfe5, 1, 2, 2]*USfC[Sfe5, 1, 2, 2]*
      (SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*(SW*ZNeuC[Neu5, 1] + 
       CW*ZNeuC[Neu5, 2]))/((-MNeu2[Neu5] + MSf2[1, 1, 2])*
      (MSf2[1, 1, 2] - MSf2[Sfe5, 2, 2])) + 
    (2*A0[MSf2[Sfe5, 2, 2]]*MSf2[Sfe5, 2, 2]*USf[Sfe5, 1, 2, 2]*
      USfC[Sfe5, 1, 2, 2]*(SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*
      (SW*ZNeuC[Neu5, 1] + CW*ZNeuC[Neu5, 2]))/
     ((MNeu2[Neu5] - MSf2[Sfe5, 2, 2])*(-MSf2[1, 1, 2] + MSf2[Sfe5, 2, 2])) + 
    USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*
     (-((SW2*ZNeu[Neu5, 1] + CW*SW*ZNeu[Neu5, 2])*ZNeuC[Neu5, 1]) + 
      (CW*SW*ZNeu[Neu5, 1] + CW2*ZNeu[Neu5, 2])*ZNeuC[Neu5, 2]) - 
    2*A0[MNeu2[Neu5]]*MNeu2[Neu5]*((USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*
        (SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*(SW*ZNeuC[Neu5, 1] - 
         CW*ZNeuC[Neu5, 2]))/((MNeu2[Neu5] - MSf2[1, 1, 1])*
        (MNeu2[Neu5] - MSf2[Sfe5, 2, 1])) + 
      (USf[Sfe5, 1, 2, 2]*USfC[Sfe5, 1, 2, 2]*(SW*ZNeu[Neu5, 1] - 
         CW*ZNeu[Neu5, 2])*(SW*ZNeuC[Neu5, 1] + CW*ZNeuC[Neu5, 2]))/
       ((MNeu2[Neu5] - MSf2[1, 1, 2])*(MNeu2[Neu5] - MSf2[Sfe5, 2, 2]))) + 
    USf[Sfe5, 1, 2, 2]*USfC[Sfe5, 1, 2, 2]*
     (ZNeu[Neu5, 2]*(CW*SW*ZNeuC[Neu5, 1] + CW2*ZNeuC[Neu5, 2]) - 
      ZNeu[Neu5, 1]*(SW2*ZNeuC[Neu5, 1] + CW*SW*ZNeuC[Neu5, 2]))))/
  (32*CW2*Pi*SW2) + SumOver[Cha5, 2]*SumOver[Neu5, 4]*
  (SumOver[Sfe5, 2]*
    ((Alfa*MW2*(-((A0[MCha2[Cha5]]*MCha2[Cha5])/((MCha2[Cha5] - MNeu2[Neu5])*
           (MCha2[Cha5] - MSf2[Sfe5, 2, 2])*(MCha2[Cha5] - 
            MSf2[Sfe6, 2, 1]))) + (A0[MNeu2[Neu5]]*MNeu2[Neu5])/
         ((MCha2[Cha5] - MNeu2[Neu5])*(MNeu2[Neu5] - MSf2[Sfe5, 2, 2])*
          (MNeu2[Neu5] - MSf2[Sfe6, 2, 1])) + 
        ((A0[MSf2[Sfe5, 2, 2]]*MSf2[Sfe5, 2, 2])/
           ((MCha2[Cha5] - MSf2[Sfe5, 2, 2])*(-MNeu2[Neu5] + 
             MSf2[Sfe5, 2, 2])) + (A0[MSf2[Sfe6, 2, 1]]*MSf2[Sfe6, 2, 1])/
           ((MCha2[Cha5] - MSf2[Sfe6, 2, 1])*(MNeu2[Neu5] - 
             MSf2[Sfe6, 2, 1])))/(MSf2[Sfe5, 2, 2] - MSf2[Sfe6, 2, 1]))*
       SumOver[Sfe6, 2]*UCha[Cha5, 1]*UChaC[Cha5, 1]*USf[Sfe5, 1, 2, 2]*
       USf[Sfe6, 1, 2, 1]*USfC[Sfe5, 1, 2, 2]*USfC[Sfe6, 1, 2, 1]*
       (SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*(SW*ZNeuC[Neu5, 1] + 
        CW*ZNeuC[Neu5, 2]))/(16*CW2*Pi*SW2) + 
     (Alfa*(UCha[Cha5, 1]*(Sqrt[2]*UChaC[Cha5, 2]*USf[Sfe5, 1, 2, 2]*
           USfC[Sfe5, 1, 2, 2]*ZNeu[Neu5, 3]*(SW*ZNeuC[Neu5, 1] + 
            CW*ZNeuC[Neu5, 2]) + 2*UChaC[Cha5, 1]*
           (USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + 
              CW*ZNeu[Neu5, 2])*ZNeuC[Neu5, 2] + USf[Sfe5, 1, 2, 2]*
             USfC[Sfe5, 1, 2, 2]*ZNeu[Neu5, 2]*(SW*ZNeuC[Neu5, 1] + 
              CW*ZNeuC[Neu5, 2]))) + Sqrt[2]*UCha[Cha5, 2]*UChaC[Cha5, 1]*
         USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + 
          CW*ZNeu[Neu5, 2])*ZNeuC[Neu5, 3] + (2*A0[MSf2[Sfe5, 2, 1]]*
          UChaC[Cha5, 1]*USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*
          (SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*(2*MCha[Cha5]*MNeu[Neu5]*
            (-2*VChaC[Cha5, 1]*ZNeu[Neu5, 2] + Sqrt[2]*VChaC[Cha5, 2]*
              ZNeu[Neu5, 4]) + MSf2[Sfe5, 2, 1]*(2*UCha[Cha5, 1]*
              ZNeuC[Neu5, 2] + Sqrt[2]*UCha[Cha5, 2]*ZNeuC[Neu5, 3])))/
         ((MCha2[Cha5] - MSf2[Sfe5, 2, 1])*(-MNeu2[Neu5] + 
           MSf2[Sfe5, 2, 1])) - (4*A0[MCha2[Cha5]]*
          ((MCha[Cha5]*MNeu[Neu5]*UChaC[Cha5, 1]*USf[Sfe5, 1, 2, 1]*
             USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*
             (2*VChaC[Cha5, 1]*ZNeu[Neu5, 2] - Sqrt[2]*VChaC[Cha5, 2]*ZNeu[
                Neu5, 4]))/(MCha2[Cha5] - MSf2[Sfe5, 2, 1]) - 
           (MCha2[Cha5]*UCha[Cha5, 1]*USf[Sfe5, 1, 2, 2]*USfC[Sfe5, 1, 2, 2]*
             (2*UChaC[Cha5, 1]*ZNeu[Neu5, 2] + Sqrt[2]*UChaC[Cha5, 2]*ZNeu[
                Neu5, 3])*(SW*ZNeuC[Neu5, 1] + CW*ZNeuC[Neu5, 2]))/
            (2*(MCha2[Cha5] - MSf2[Sfe5, 2, 2])) + 
           (MCha2[Cha5]*UChaC[Cha5, 1]*USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*
             (SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*(UCha[Cha5, 1]*ZNeuC[Neu5, 
                2] + (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/Sqrt[2]))/
            (-MCha2[Cha5] + MSf2[Sfe5, 2, 1]) + (MCha[Cha5]*MNeu[Neu5]*
             UCha[Cha5, 1]*USf[Sfe5, 1, 2, 2]*USfC[Sfe5, 1, 2, 2]*
             (SW*ZNeuC[Neu5, 1] + CW*ZNeuC[Neu5, 2])*(2*VCha[Cha5, 1]*ZNeuC[
                Neu5, 2] - Sqrt[2]*VCha[Cha5, 2]*ZNeuC[Neu5, 4]))/
            (MCha2[Cha5] - MSf2[Sfe5, 2, 2])))/(-MCha2[Cha5] + MNeu2[Neu5]) - 
        (4*A0[MNeu2[Neu5]]*((2*MCha[Cha5]*MNeu[Neu5]*UChaC[Cha5, 1]*
             USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*(SW*ZNeu[Neu5, 1] + 
              CW*ZNeu[Neu5, 2])*(VChaC[Cha5, 1]*ZNeu[Neu5, 2] - 
              (VChaC[Cha5, 2]*ZNeu[Neu5, 4])/Sqrt[2]))/(-MNeu2[Neu5] + 
             MSf2[Sfe5, 2, 1]) + (MNeu2[Neu5]*UCha[Cha5, 1]*
             USf[Sfe5, 1, 2, 2]*USfC[Sfe5, 1, 2, 2]*(2*UChaC[Cha5, 1]*ZNeu[
                Neu5, 2] + Sqrt[2]*UChaC[Cha5, 2]*ZNeu[Neu5, 3])*
             (SW*ZNeuC[Neu5, 1] + CW*ZNeuC[Neu5, 2]))/
            (2*(MNeu2[Neu5] - MSf2[Sfe5, 2, 2])) - 
           (MNeu2[Neu5]*UChaC[Cha5, 1]*USf[Sfe5, 1, 2, 1]*USfC[Sfe5, 1, 2, 1]*
             (SW*ZNeu[Neu5, 1] + CW*ZNeu[Neu5, 2])*(UCha[Cha5, 1]*ZNeuC[Neu5, 
                2] + (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/Sqrt[2]))/
            (-MNeu2[Neu5] + MSf2[Sfe5, 2, 1]) - (MCha[Cha5]*MNeu[Neu5]*
             UCha[Cha5, 1]*USf[Sfe5, 1, 2, 2]*USfC[Sfe5, 1, 2, 2]*
             (SW*ZNeuC[Neu5, 1] + CW*ZNeuC[Neu5, 2])*(2*VCha[Cha5, 1]*ZNeuC[
                Neu5, 2] - Sqrt[2]*VCha[Cha5, 2]*ZNeuC[Neu5, 4]))/
            (MNeu2[Neu5] - MSf2[Sfe5, 2, 2])))/(-MCha2[Cha5] + MNeu2[Neu5]) + 
        (2*A0[MSf2[Sfe5, 2, 2]]*UCha[Cha5, 1]*USf[Sfe5, 1, 2, 2]*
          USfC[Sfe5, 1, 2, 2]*(SW*ZNeuC[Neu5, 1] + CW*ZNeuC[Neu5, 2])*
          (MSf2[Sfe5, 2, 2]*(2*UChaC[Cha5, 1]*ZNeu[Neu5, 2] + 
             Sqrt[2]*UChaC[Cha5, 2]*ZNeu[Neu5, 3]) + 2*MCha[Cha5]*MNeu[Neu5]*
            (-2*VCha[Cha5, 1]*ZNeuC[Neu5, 2] + Sqrt[2]*VCha[Cha5, 2]*
              ZNeuC[Neu5, 4])))/((MCha2[Cha5] - MSf2[Sfe5, 2, 2])*
          (-MNeu2[Neu5] + MSf2[Sfe5, 2, 2]))))/(32*CW*Pi*SW2)) + 
   (Alfa*((2*A0[MSf2[1, 1, 1]]*VCha[Cha5, 1]*(MSf2[1, 1, 1]*VChaC[Cha5, 1]*
          (-(CW2*(MW2 + 2*MSf2[1, 1, 1] - 2*MSf2[1, 1, 2])*ZNeu[Neu5, 2]*
             (SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2])) + MW2*ZNeu[Neu5, 1]*
            (CW*SW2*ZNeuC[Neu5, 1] - CW2*SW*ZNeuC[Neu5, 2])) + 
         CW2*(MSf2[1, 1, 1] - MSf2[1, 1, 2])*(SW*ZNeuC[Neu5, 1] - 
           CW*ZNeuC[Neu5, 2])*(Sqrt[2]*MSf2[1, 1, 1]*VChaC[Cha5, 2]*
            ZNeu[Neu5, 4] + 2*MCha[Cha5]*MNeu[Neu5]*
            (2*UCha[Cha5, 1]*ZNeuC[Neu5, 2] + Sqrt[2]*UCha[Cha5, 2]*
              ZNeuC[Neu5, 3]))))/(CW*CW2*(MCha2[Cha5] - MSf2[1, 1, 1])*
        (-MNeu2[Neu5] + MSf2[1, 1, 1])*(MSf2[1, 1, 1] - MSf2[1, 1, 2])) + 
      (VCha[Cha5, 1]*(Sqrt[2]*VChaC[Cha5, 2]*ZNeu[Neu5, 4]*
           (SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2]) - 2*VChaC[Cha5, 1]*
           (SW*ZNeu[Neu5, 1]*ZNeuC[Neu5, 2] + ZNeu[Neu5, 2]*
             (SW*ZNeuC[Neu5, 1] - 2*CW*ZNeuC[Neu5, 2]))) + 
        Sqrt[2]*VCha[Cha5, 2]*VChaC[Cha5, 1]*(SW*ZNeu[Neu5, 1] - 
          CW*ZNeu[Neu5, 2])*ZNeuC[Neu5, 4])/CW + 
      (2*A0[MSf2[1, 1, 2]]*VChaC[Cha5, 1]*(-2*CW2*MCha[Cha5]*MNeu[Neu5]*
          (MSf2[1, 1, 1] - MSf2[1, 1, 2])*(SW*ZNeu[Neu5, 1] - 
           CW*ZNeu[Neu5, 2])*(2*UChaC[Cha5, 1]*ZNeu[Neu5, 2] + 
           Sqrt[2]*UChaC[Cha5, 2]*ZNeu[Neu5, 3]) + MSf2[1, 1, 2]*
          (VCha[Cha5, 1]*(MW2*(CW*SW2*ZNeu[Neu5, 1] - CW2*SW*ZNeu[Neu5, 2])*
              ZNeuC[Neu5, 1] + CW2*(MW2 - 2*MSf2[1, 1, 1] + 2*MSf2[1, 1, 2])*
              (-(SW*ZNeu[Neu5, 1]) + CW*ZNeu[Neu5, 2])*ZNeuC[Neu5, 2]) - 
           Sqrt[2]*CW2*(MSf2[1, 1, 1] - MSf2[1, 1, 2])*VCha[Cha5, 2]*
            (SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*ZNeuC[Neu5, 4])))/
       (CW*CW2*(MCha2[Cha5] - MSf2[1, 1, 2])*(-MNeu2[Neu5] + MSf2[1, 1, 2])*
        (-MSf2[1, 1, 1] + MSf2[1, 1, 2])) + 
      (2*MW2*A0[MCha2[Cha5]]*((MCha2[Cha5]*VCha[Cha5, 1]*VChaC[Cha5, 1]*
           (SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*(SW*ZNeuC[Neu5, 1] - 
            CW*ZNeuC[Neu5, 2]))/(CW2*(MCha2[Cha5] - MSf2[1, 1, 1])*
           (MCha2[Cha5] - MSf2[1, 1, 2])) - 
         (2*(2*MCha[Cha5]*MNeu[Neu5]*((VChaC[Cha5, 1]*(SW*ZNeu[Neu5, 1] - 
                 CW*ZNeu[Neu5, 2])*(UChaC[Cha5, 1]*ZNeu[Neu5, 2] + 
                 (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/Sqrt[2]))/(-MCha2[Cha5] + 
                MSf2[1, 1, 2]) + (VCha[Cha5, 1]*(SW*ZNeuC[Neu5, 1] - 
                 CW*ZNeuC[Neu5, 2])*(UCha[Cha5, 1]*ZNeuC[Neu5, 2] + 
                 (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/Sqrt[2]))/(-MCha2[Cha5] + 
                MSf2[1, 1, 1])) - MCha2[Cha5]*((VCha[Cha5, 1]*
                (VChaC[Cha5, 1]*ZNeu[Neu5, 2] - (VChaC[Cha5, 2]*ZNeu[Neu5, 
                    4])/Sqrt[2])*(SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2]))/(
                -MCha2[Cha5] + MSf2[1, 1, 1]) + (VChaC[Cha5, 1]*
                (SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*(VCha[Cha5, 1]*
                  ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/Sqrt[2]))/(
                -MCha2[Cha5] + MSf2[1, 1, 2]))))/(CW*MW2)))/
       (-MCha2[Cha5] + MNeu2[Neu5]) + (2*MW2*A0[MNeu2[Neu5]]*
        ((MNeu2[Neu5]*VCha[Cha5, 1]*VChaC[Cha5, 1]*(SW*ZNeu[Neu5, 1] - 
            CW*ZNeu[Neu5, 2])*(-(SW*ZNeuC[Neu5, 1]) + CW*ZNeuC[Neu5, 2]))/
          (CW2*(MNeu2[Neu5] - MSf2[1, 1, 1])*(MNeu2[Neu5] - MSf2[1, 1, 2])) - 
         (2*(-2*MCha[Cha5]*MNeu[Neu5]*((VChaC[Cha5, 1]*(SW*ZNeu[Neu5, 1] - 
                 CW*ZNeu[Neu5, 2])*(UChaC[Cha5, 1]*ZNeu[Neu5, 2] + 
                 (UChaC[Cha5, 2]*ZNeu[Neu5, 3])/Sqrt[2]))/(-MNeu2[Neu5] + 
                MSf2[1, 1, 2]) + (VCha[Cha5, 1]*(SW*ZNeuC[Neu5, 1] - 
                 CW*ZNeuC[Neu5, 2])*(UCha[Cha5, 1]*ZNeuC[Neu5, 2] + 
                 (UCha[Cha5, 2]*ZNeuC[Neu5, 3])/Sqrt[2]))/(-MNeu2[Neu5] + 
                MSf2[1, 1, 1])) + MNeu2[Neu5]*((VCha[Cha5, 1]*
                (VChaC[Cha5, 1]*ZNeu[Neu5, 2] - (VChaC[Cha5, 2]*ZNeu[Neu5, 
                    4])/Sqrt[2])*(SW*ZNeuC[Neu5, 1] - CW*ZNeuC[Neu5, 2]))/(
                -MNeu2[Neu5] + MSf2[1, 1, 1]) + (VChaC[Cha5, 1]*
                (SW*ZNeu[Neu5, 1] - CW*ZNeu[Neu5, 2])*(VCha[Cha5, 1]*
                  ZNeuC[Neu5, 2] - (VCha[Cha5, 2]*ZNeuC[Neu5, 4])/Sqrt[2]))/(
                -MNeu2[Neu5] + MSf2[1, 1, 2]))))/(CW*MW2)))/
       (-MCha2[Cha5] + MNeu2[Neu5])))/(32*Pi*SW2))
