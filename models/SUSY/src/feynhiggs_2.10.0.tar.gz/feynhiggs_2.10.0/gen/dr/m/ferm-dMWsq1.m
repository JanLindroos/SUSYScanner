(-(Alfa*A0[Mf2[2, Gen3]])/(4*Pi*SW2) - (3*Alfa*A0[Mf2[4, Gen3]])/(4*Pi*SW2) + 
  (Alfa*B0i[bb00, MW2, 0, Mf2[2, Gen3]])/(2*Pi*SW2) + 
  (3*Alfa*B0i[bb00, MW2, Mf2[3, Gen3], Mf2[4, Gen3]])/(2*Pi*SW2) - 
  (Alfa*MW2*B0i[bb1, MW2, 0, Mf2[2, Gen3]])/(4*Pi*SW2) - 
  (3*Alfa*MW2*B0i[bb1, MW2, Mf2[3, Gen3], Mf2[4, Gen3]])/(4*Pi*SW2) - 
  (3*Alfa*B0i[bb0, MW2, Mf2[3, Gen3], Mf2[4, Gen3]]*Mf2[3, Gen3])/(4*Pi*SW2))*
 SumOver[Gen3, 3]
