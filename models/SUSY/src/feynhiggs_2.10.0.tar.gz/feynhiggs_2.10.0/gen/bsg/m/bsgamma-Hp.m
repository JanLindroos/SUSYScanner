((I/12)*CKM[Gen4, 3]*CKMC[Gen4, 2]*Mat[O7[6]]*Mf2[3, Gen4]*
  (2*A0[MHp2]*(MHp2 - MB*TB2*Mf[bTR, 3] - Mf2[3, Gen4]) + 
   2*A0[Mf2[3, Gen4]]*(-MHp2 + MB*TB2*Mf[bTR, 3] + Mf2[3, Gen4]) - 
   (MHp2 - Mf2[3, Gen4])*(2*B0[MB2, MHp2, Mf2[3, Gen4]]*
      (MHp2 - MB*TB2*Mf[bTR, 3] - Mf2[3, Gen4]) + 
     MB2*(5 + 6*MHp2*C0[MB2, 0, 0, MHp2, Mf2[3, Gen4], MHp2] + 
       4*C0[MB2, 0, 0, MHp2, Mf2[3, Gen4], Mf2[3, Gen4]]*
        (MB*TB2*Mf[bTR, 3] + Mf2[3, Gen4]))))*SumOver[Gen4, 3])/
 (MB2^2*TB2*CKM[3, 3]*CKMC[3, 2]*(-MHp2 + Mf2[3, Gen4]))
