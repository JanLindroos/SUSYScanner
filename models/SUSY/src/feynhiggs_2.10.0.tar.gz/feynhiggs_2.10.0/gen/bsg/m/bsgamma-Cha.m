((I/12)*Mat[O7[6]]*SumOver[All4, 6]*SumOver[Cha4, 2]*SumOver[Ind1, 3]*
  SumOver[Ind2, 3]*((CKM[Ind1, 3]*CKMC[Ind2, 2]*(-A0[MASf2[All4, 3]] + 
      A0[MCha2[Cha4]] - MB2*(5 + 4*C0[MB2, 0, 0, MASf2[All4, 3], MCha2[Cha4], 
          MASf2[All4, 3]]*MASf2[All4, 3] + 6*C0[MB2, 0, 0, MASf2[All4, 3], 
          MCha2[Cha4], MCha2[Cha4]]*MASf2[All4, 3]) + 
      B0[MB2, MASf2[All4, 3], MCha2[Cha4]]*(MB2 + MASf2[All4, 3] - 
        MCha2[Cha4]))*(2*MW*SB*UASfC[All4, Ind2, 3]*VCha[Cha4, 1] - 
      Sqrt[2]*Mf[3, Ind2]*UASfC[All4, 3 + Ind2, 3]*VCha[Cha4, 2])*
     (2*MW*SB*UASf[All4, Ind1, 3]*VChaC[Cha4, 1] - Sqrt[2]*Mf[3, Ind1]*
       UASf[All4, 3 + Ind1, 3]*VChaC[Cha4, 2]))/(2*MB2*SB2) + 
   ((Sqrt[2]*MB*CKM[Ind2, 3]*CKMC[Ind1, 2]*MCha[Cha4]*
       (-B0[MB2, MASf2[All4, 3], MCha2[Cha4]] + 
        (A0[MASf2[All4, 3]] - A0[MCha2[Cha4]])/(MASf2[All4, 3] - 
          MCha2[Cha4]))*Mf[bTR, 3]*UASf[All4, Ind2, 3]*UCha[Cha4, 2]*
       (-2*MW*SB*UASfC[All4, Ind1, 3]*VCha[Cha4, 1] + Sqrt[2]*Mf[3, Ind1]*
         UASfC[All4, 3 + Ind1, 3]*VCha[Cha4, 2]))/(CB*SB) - 
     (CKM[Ind1, 3]*CKMC[Ind2, 2]*(A0[MASf2[All4, 3]] - A0[MCha2[Cha4]] + 
        B0[MB2, MASf2[All4, 3], MCha2[Cha4]]*(MB2 - MASf2[All4, 3] + 
          MCha2[Cha4]))*(2*MW*SB*UASfC[All4, Ind2, 3]*VCha[Cha4, 1] - 
        Sqrt[2]*Mf[3, Ind2]*UASfC[All4, 3 + Ind2, 3]*VCha[Cha4, 2])*
       (2*MW*SB*UASf[All4, Ind1, 3]*VChaC[Cha4, 1] - Sqrt[2]*Mf[3, Ind1]*
         UASf[All4, 3 + Ind1, 3]*VChaC[Cha4, 2]))/(2*SB2))/MB2 - 
   3*C0[MB2, 0, 0, MASf2[All4, 3], MCha2[Cha4], MCha2[Cha4]]*
    ((2*MB*CKM[Ind2, 3]*CKMC[Ind1, 2]*MCha[Cha4]*Mf[bTR, 3]*
       UASf[All4, Ind2, 3]*UCha[Cha4, 2]*
       (-(Sqrt[2]*MW*SB*UASfC[All4, Ind1, 3]*VCha[Cha4, 1]) + 
        Mf[3, Ind1]*UASfC[All4, 3 + Ind1, 3]*VCha[Cha4, 2]))/(CB*SB) + 
     (CKM[Ind1, 3]*CKMC[Ind2, 2]*(-MASf2[All4, 3] + MCha2[Cha4])*
       (-2*MW*SB*UASfC[All4, Ind2, 3]*VCha[Cha4, 1] + Sqrt[2]*Mf[3, Ind2]*
         UASfC[All4, 3 + Ind2, 3]*VCha[Cha4, 2])*
       (-2*MW*SB*UASf[All4, Ind1, 3]*VChaC[Cha4, 1] + Sqrt[2]*Mf[3, Ind1]*
         UASf[All4, 3 + Ind1, 3]*VChaC[Cha4, 2]))/SB2)))/
 (MB2*CKM[3, 3]*CKMC[3, 2])
