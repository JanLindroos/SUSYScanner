((-I/18)*MW2*SumOver[All4, 6]*SumOver[Neu4, 4]*
  ((2*SW2*Mat[O8[7]]*UASfC[All4, 5, bTR]*ZNeuC[Neu4, 1]*
     (((MB2 - A0[MASf2[All4, bTR]] + A0[MNeu2[Neu4]] + 
         2*MB2*C0[MB2, 0, 0, MASf2[All4, bTR], MNeu2[Neu4], MASf2[All4, bTR]]*
          MASf2[All4, bTR] + B0[MB2, MASf2[All4, bTR], MNeu2[Neu4]]*
          (MB2 + MASf2[All4, bTR] - MNeu2[Neu4]))*
        (2*CB*MW*SW*UASf[All4, 6, bTR]*ZNeu[Neu4, 1] + 3*CW*Mf[bTR, 3]*
          UASf[All4, 3, bTR]*ZNeu[Neu4, 3]))/2 - 
      ((A0[MASf2[All4, bTR]] - A0[MNeu2[Neu4]] + 
         B0[MB2, MASf2[All4, bTR], MNeu2[Neu4]]*(MB2 - MASf2[All4, bTR] + 
           MNeu2[Neu4]))*(2*CB*MW*SW*UASf[All4, 6, bTR]*ZNeu[Neu4, 1] + 
         3*CW*Mf[bTR, 3]*UASf[All4, 3, bTR]*ZNeu[Neu4, 3]))/2 + 
      MB*MNeu[Neu4]*(-B0[MB2, MASf2[All4, bTR], MNeu2[Neu4]] + 
        (A0[MASf2[All4, bTR]] - A0[MNeu2[Neu4]])/(MASf2[All4, bTR] - 
          MNeu2[Neu4]))*(CB*MW*UASf[All4, 3, bTR]*(SW*ZNeuC[Neu4, 1] - 
          3*CW*ZNeuC[Neu4, 2]) + 3*CW*Mf[bTR, 3]*UASf[All4, 6, bTR]*
         ZNeuC[Neu4, 3])))/SW + Mat[O8[6]]*UASfC[All4, 2, bTR]*
    (SW*ZNeu[Neu4, 1] - 3*CW*ZNeu[Neu4, 2])*
    (-(MB*B0[MB2, MASf2[All4, bTR], MNeu2[Neu4]]*MNeu[Neu4]*
       (2*CB*MW*SW*UASf[All4, 6, bTR]*ZNeu[Neu4, 1] + 
        3*CW*Mf[bTR, 3]*UASf[All4, 3, bTR]*ZNeu[Neu4, 3])) + 
     (MB*(A0[MASf2[All4, bTR]] - A0[MNeu2[Neu4]])*MNeu[Neu4]*
       (2*CB*MW*SW*UASf[All4, 6, bTR]*ZNeu[Neu4, 1] + 
        3*CW*Mf[bTR, 3]*UASf[All4, 3, bTR]*ZNeu[Neu4, 3]))/
      (MASf2[All4, bTR] - MNeu2[Neu4]) + 
     ((MB2 - 2*A0[MASf2[All4, bTR]] + 2*A0[MNeu2[Neu4]] + 
        2*MB2*C0[MB2, 0, 0, MASf2[All4, bTR], MNeu2[Neu4], MASf2[All4, bTR]]*
         MASf2[All4, bTR] + 2*B0[MB2, MASf2[All4, bTR], MNeu2[Neu4]]*
         (MASf2[All4, bTR] - MNeu2[Neu4]))*(CB*MW*UASf[All4, 3, bTR]*
         (SW*ZNeuC[Neu4, 1] - 3*CW*ZNeuC[Neu4, 2]) + 3*CW*Mf[bTR, 3]*
         UASf[All4, 6, bTR]*ZNeuC[Neu4, 3]))/2)))/
 (CB*CW2*MB2^2*MW*CKM[3, 3]*CKMC[3, 2])
